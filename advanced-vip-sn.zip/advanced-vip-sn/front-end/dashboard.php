<?php
	if( ! defined('ABSPATH') ) die();
	function av_dashbourd_func(){ ?>
	<div class="wrap av-dashboard">
	
		<div class="av-dashboard-box">
			<p>افزونه حرفه ای عضویت ویژه</p>
			</div>
		
	</div>
	<?php } 